// Función para mostrar un mensaje de bienvenida cuando se hace clic en un botón
function mostrarMensaje() {
    alert("¡Gracias por visitar mi página!");
}
